package com.madhumankatha.brudavanstore.utils;

public class WebEndPoints {
    public static final String ROOT_URL = "https://www.bscart.com";

    public static final String GROCERY = "https://www.bscart.com/category.php?cid=1";
    public static final String HOME = "https://www.bscart.com/category.php?cid=2";
    public static final String PERSONAL = "https://www.bscart.com/category.php?cid=3";
    public static final String BABY = "https://www.bscart.com/category.php?cid=4";
    public static final String BEAUTY = "https://www.bscart.com/category.php?cid=5";
    public static final String ELECTRICAL = "https://www.bscart.com/category.php?cid=7";
    public static final String FROZEN = "https://www.bscart.com/category.php?cid=8";
    //public static final String BEAUTY = "https://www.bscart.com/category.php?cid=5";

    public static final String CART = "https://www.bscart.com/my-cart.php";
    public static final String MY_ACCOUNT = "https://www.bscart.com/my-account.php";
    public static final String LOGIN = "https://www.bscart.com/login.php";

    public static final String TERMS = "https://www.bscart.com/termsncondition.php";
    public static final String PRIVACY = "https://www.bscart.com/privacypolicy.php";

}
