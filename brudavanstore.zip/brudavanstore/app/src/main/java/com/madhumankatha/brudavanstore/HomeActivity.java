package com.madhumankatha.brudavanstore;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.appcompat.app.ActionBarDrawerToggle;

import android.view.MenuItem;

import com.google.android.material.navigation.NavigationView;
import com.madhumankatha.brudavanstore.fragments.WebComponent;
import com.madhumankatha.brudavanstore.utils.NotificationService;
import com.madhumankatha.brudavanstore.utils.PushOpenHandler;
import com.madhumankatha.brudavanstore.utils.PushReciever;
import com.madhumankatha.brudavanstore.utils.WebEndPoints;
import com.onesignal.NotificationExtenderService;
import com.onesignal.OSNotificationAction;
import com.onesignal.OSNotificationOpenResult;
import com.onesignal.OSNotificationReceivedResult;
import com.onesignal.OSPermissionObserver;
import com.onesignal.OSPermissionStateChanges;
import com.onesignal.OneSignal;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.Toast;

import org.json.JSONObject;

public class HomeActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, OSPermissionObserver {
    private Context context;
    private WebComponent webComponent = new WebComponent();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = this;
        OneSignal.addPermissionObserver(this);
        // OneSignal Initialization
        OneSignal.startInit(this)
                .inFocusDisplaying(OneSignal.OSInFocusDisplayOption.Notification)
                .unsubscribeWhenNotificationsAreDisabled(true)
                .setNotificationReceivedHandler(new PushReciever())
                .setNotificationOpenedHandler(new PushOpenHandler(context))
                .filterOtherGCMReceivers(true)
                .disableGmsMissingPrompt(true)
                .init();

        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_terms) {
            webComponent.displayWeb(WebEndPoints.TERMS);
            return true;
        }else if (id == R.id.action_privacy){
            webComponent.displayWeb(WebEndPoints.PRIVACY);
        }
        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        Bundle bundle = new Bundle();
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_grocery) {
            WebComponent.displayWeb(WebEndPoints.GROCERY);
        } else if (id == R.id.nav_home) {
            WebComponent.displayWeb(WebEndPoints.HOME);
        } else if (id == R.id.nav_personal) {
            WebComponent.displayWeb(WebEndPoints.PERSONAL);
        } else if (id == R.id.nav_baby) {
            WebComponent.displayWeb(WebEndPoints.BABY);
        } else if (id == R.id.nav_beauty) {
            WebComponent.displayWeb(WebEndPoints.BEAUTY);
        } else if (id == R.id.nav_electrical) {
            WebComponent.displayWeb(WebEndPoints.ELECTRICAL);
        }else if (id == R.id.nav_frozen) {
            WebComponent.displayWeb(WebEndPoints.FROZEN);
        }else if (id == R.id.nav_my_account) {
            WebComponent.displayWeb(WebEndPoints.MY_ACCOUNT);
        }else if (id == R.id.nav_my_cart) {
            WebComponent.displayWeb(WebEndPoints.CART);
        }else if (id == R.id.nav_login) {
            WebComponent.displayWeb(WebEndPoints.LOGIN);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onOSPermissionChanged(OSPermissionStateChanges stateChanges) {
        if (stateChanges.getFrom().getEnabled() &&
                !stateChanges.getTo().getEnabled()) {
            new AlertDialog.Builder(this)
                    .setMessage("Notifications Disabled!")
                    .show();
        }
    }
}
