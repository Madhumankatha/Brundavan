package com.madhumankatha.brudavanstore.fragments;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.madhumankatha.brudavanstore.R;
import com.madhumankatha.brudavanstore.databinding.WebcomponentBinding;
import com.madhumankatha.brudavanstore.utils.WebAppInterface;
import com.madhumankatha.brudavanstore.utils.WebEndPoints;

public class WebComponent extends Fragment {
    private static WebcomponentBinding binding;
    private static Context ctx;
    public static final String URL = "https://www.bscart.com";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.webcomponent,container,false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ctx = getActivity();

        //String murl = this.getArguments().getString("url");

        displayWeb(WebEndPoints.ROOT_URL);
    }

    public static void displayWeb(String WEBURL){
        binding.webView.getSettings().setLoadsImagesAutomatically(true);
        binding.webView.getSettings().setJavaScriptEnabled(true);
        binding.webView.getSettings().setLoadWithOverviewMode(true);
        binding.webView.getSettings().setUseWideViewPort(true);
        binding.webView.getSettings().setSupportZoom(true);
        binding.webView.getSettings().setBuiltInZoomControls(false);
        binding.webView.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        binding.webView.getSettings().setCacheMode(binding.webView.getSettings().LOAD_CACHE_ELSE_NETWORK);
        binding.webView.getSettings().setAppCacheEnabled(true);
        binding.webView.getSettings().setDomStorageEnabled(true);
        binding.webView.setScrollBarStyle(WebView.SCROLLBARS_OUTSIDE_OVERLAY);
        binding.webView.canGoBack();
        binding.webView.goBack();
        binding.webView.getSettings().setEnableSmoothTransition(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            binding.webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            binding.webView.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        binding.webView.setWebViewClient(new MyBrowserClient());
        binding.webView.addJavascriptInterface(new WebAppInterface(ctx),"brudavanApp");
        binding.webView.loadUrl(WEBURL);
        binding.webView.canGoBack();
        binding.webView.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == MotionEvent.ACTION_UP
                    && binding.webView.canGoBack()) {
                binding.webView.goBack();
                return true;
            }
            return false;
        });
    }

    private static class MyBrowserClient extends WebViewClient{
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            binding.webViewProgressBar.setVisibility(View.VISIBLE);
            view.loadUrl(url);
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            binding.webViewProgressBar.setVisibility(View.GONE);
        }
    }




    @Override
    public void onDestroy() {
        super.onDestroy();
        binding.webView.clearHistory();
        binding.webView.clearView();
        binding.webView.removeAllViews();
        binding.webView.destroy();

    }
}
