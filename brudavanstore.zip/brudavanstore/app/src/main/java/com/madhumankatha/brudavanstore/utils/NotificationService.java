package com.madhumankatha.brudavanstore.utils;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;
import androidx.core.app.TaskStackBuilder;

import com.madhumankatha.brudavanstore.HomeActivity;
import com.madhumankatha.brudavanstore.R;
import com.onesignal.NotificationExtenderService;
import com.onesignal.OSNotificationReceivedResult;

public class NotificationService extends NotificationExtenderService {
    private Context context = NotificationService.this;
    @Override
    protected boolean onNotificationProcessing(OSNotificationReceivedResult notification) {

        OverrideSettings overrideSettings = new OverrideSettings();
        overrideSettings.extender = builder -> {
            if (!notification.restoring) {
                // Only set custom channel if notification is not being restored
                // Note: this would override any channels set through the OneSignal dashboard
                return builder.setChannelId("Brudavan Store");
            }
            return builder;
        };

        /* Do something with notification payload */
        String title = notification.payload.title;
        String body  = notification.payload.body;
        //String additionalData = notification.payload.additionalData.toString();

        Log.i("Notification Title : ",title);
        Log.i("Notification Body : ",body);
        //Log.i("additionalData : ",additionalData);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            notificationDialog("Brudavan",title,body,body);
            return true;
        }else {
            return false;
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void notificationDialog(String ticker,String title,String msg,String content) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        String NOTIFICATION_CHANNEL_ID = "Brudavan Store";

        Uri ringTone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        Bitmap largeIcon = BitmapFactory.decodeResource(getResources(),R.drawable.logo);

        NotificationCompat.BigTextStyle bigTextStyle = new NotificationCompat.BigTextStyle();
        bigTextStyle.bigText(content);

        Intent resultIntent = new Intent(context, HomeActivity.class);
// Create the TaskStackBuilder and add the intent, which inflates the back stack
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(context);
        stackBuilder.addNextIntentWithParentStack(resultIntent);
// Get the PendingIntent containing the entire back stack
        PendingIntent resultPendingIntent =
                stackBuilder.getPendingIntent(0, PendingIntent.FLAG_UPDATE_CURRENT);


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            @SuppressLint("WrongConstant") NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "Brundavan Store", NotificationManager.IMPORTANCE_MAX);
            // Configure the notification channel.
            notificationChannel.setDescription("Brudavan Store Notifications");
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);
        }
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID);
        notificationBuilder.setAutoCancel(true)
                .setDefaults(Notification.DEFAULT_ALL)
                .setWhen(System.currentTimeMillis())
                .setSmallIcon(R.drawable.ic_app_notifications)
                .setContentIntent(resultPendingIntent)
                .setLargeIcon(largeIcon)
                .setStyle(bigTextStyle)
                .setTicker(ticker)
                .setPriority(Notification.PRIORITY_MAX)
                .setContentTitle(title)
                .setSound(ringTone);
        notificationManager.notify(1, notificationBuilder.build());
    }
}
