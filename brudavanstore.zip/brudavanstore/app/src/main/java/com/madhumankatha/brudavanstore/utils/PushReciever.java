package com.madhumankatha.brudavanstore.utils;

import android.util.Log;

import com.onesignal.OSNotification;
import com.onesignal.OneSignal;

public class PushReciever implements OneSignal.NotificationReceivedHandler {
    private NotificationService notificationService = new NotificationService();

    @Override
    public void notificationReceived(OSNotification notification) {
        String title =  notification.payload.title;
        String body = notification.payload.body;

        Log.i("RTitle : ",title);
        Log.i("RBody : ",body);

        notificationService.notificationDialog("Brudavan Store",title,body,body);
    }
}
